- MongoDB -

Obter a �ltima vers�o do instalador MongoDB para Windows 64bits atrav�s do endere�o http://www.mongodb.org/downloads.

Seguir o tutorial em http://docs.mongodb.org/manual/tutorial/install-mongodb-on-windows/
e instalar o Mongo como servi�o windows.



- Servi�o de Importa��o -

Copiar os conte�dos da pasta "Servi�o de Importa��o" para o local pretendido.
Alterar os par�metros no ficheiro CitySDKImporter.exe.config.

	- MongoServer: endere�o do servidor. Default: localhost
	- MongoDatabase: default � CitySDK
	- MySQLConnectionString: connection string de liga��o � BD MySQL que cont�m os dados da CML
	- BaseAddress: endere�o base da API utilizado na defini��o dos links dos POIs

Correr o ficheiro INSTALL.bat.




- API -

Copiar a pasta CitySDK para a pasta default do IIS (C:\inetpub\wwwroot\).

Alterar os par�metros no ficheiro web.config.
	- MongoServer: endere�o do servidor. Default: localhost
	- MongoDatabase: default � CitySDK

Fazer deploy do site no IIS.